1- password is = hello_world

2- the incoming.txt, outgoing.txt, history.txt and inventory.txt files should be completely empty(including whitespace) at the start of the code.

3- all four of the above txt files should be in the same directory as the script or executable and should not be renamed.

4- the program is coded entirely in python and an executable version is also present along with the .py script

5- EXIT THE PROGRAM ONLY USING THE IN-PROGRAM PROMPT. NOT USING X OR TASK MANAGER. IT WILL BREAK OTHERWISE